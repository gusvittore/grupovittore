# Regras de imagens e assets

## Objetivo das imagens

As imagens da landing page devem reforçar a percepção premium da frente de Materiais Gráficos Personalizados.

Elas precisam comunicar:

- sofisticação;
- acabamento;
- profissionalismo;
- cuidado;
- autoridade;
- presença física da marca.

## Pastas sugeridas

Criar assets da LP em:

```txt
public/assets/materiais-graficos/
```

Sugestão de estrutura:

```txt
public/assets/materiais-graficos/
  brand/
  references/
  sections/
    hero/
    cartoes/
    pastas-envelopes/
    panfletos-folders/
    blocos/
    prova-social/
```

Se o projeto já usa `materiais-impressos` como nome de pasta, manter o padrão existente e não duplicar.

## Nomes de arquivos

Usar nomes simples, sem acentos e com hífen:

```txt
hero-materiais-graficos.webp
cartoes-visita-premium.webp
pastas-envelopes-premium.webp
panfletos-folders-profissionais.webp
blocos-anotacoes-personalizados.webp
```

## Formato recomendado

Preferir WebP otimizado para imagens finais da página.

Qualidade sugerida:

- imagens gerais: 78 a 82;
- imagem hero: 82 a 86;
- se houver transparência e o resultado em WebP ficar ruim, avaliar PNG.

## Alt text

Cada imagem deve ter alt text descritivo e natural.

Exemplos:

- `Cartões de visita premium personalizados com acabamento sofisticado`
- `Pastas e envelopes personalizados para apresentação profissional`
- `Folders e panfletos personalizados com acabamento gráfico profissional`
- `Blocos de anotações personalizados para empresas e profissionais`

## Imagens por seção

### Hero

Imagem opcional ou composição visual com materiais premium.

Não usar logo dentro da Hero.

### Cartões de visita

Foto de cartões premium, com textura, acabamento e apresentação sofisticada.

### Pastas e envelopes

Foto de pastas, envelopes e papelaria institucional com acabamento elegante.

### Panfletos e folders

Foto de folders e panfletos bem diagramados, com visual profissional.

### Blocos

Foto de blocos de anotações personalizados, em ambiente corporativo ou composição premium.

### Prova social

Não precisa de imagem real. Pode ser componente com cards de depoimentos e estrelas.

## Regras importantes

- Não mover assets existentes sem atualizar o código.
- Não renomear imagens existentes sem necessidade.
- Não usar imagens de baixa qualidade.
- Não usar imagens com texto ilegível.
- Não usar material visual que pareça popular ou barato.
- Não usar imagem genérica sem relação com material gráfico.
- Não usar fotos com pessoas como foco principal, salvo se o usuário aprovar.
