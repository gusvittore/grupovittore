# Copy final, LP Materiais Gráficos Personalizados

Este documento reúne a copy completa sugerida para a landing page.

A copy pode ser ajustada pontualmente no código para caber melhor no layout, mas não deve perder o sentido, o tom premium e o posicionamento estratégico.

---

# Seção 1, Hero principal

## Eyebrow

Materiais Gráficos Personalizados

## Título

Autoridade que se toca: impressos premium que materializam sua marca.

## Variação com destaque em dourado

Autoridade que se toca: impressos premium que materializam a presença da sua marca.

Palavras sugeridas para dourado:
- Autoridade que se toca
- impressos premium
- presença da sua marca

## Descrição

Cartões de visita, pastas, envelopes, folders, panfletos e blocos personalizados para profissionais e empresas que querem transmitir mais confiança, sofisticação e valor em cada detalhe.

## Complemento curto

Do conceito ao papel, presença que lidera.

## CTA principal

Quero mais informações

## Microcopy abaixo do botão

Pedidos sob encomenda pelo WhatsApp. Entregamos para todo o Brasil.

---

# Seção 2, Cartões de visita

## Eyebrow

Primeira impressão

## Título

Cartões de visita para quem não quer parecer comum.

## Descrição

O cartão de visita ainda é uma das formas mais diretas de materializar sua presença profissional. Quando o papel, o acabamento e o design estão alinhados, ele deixa de ser apenas um contato e passa a comunicar cuidado, autoridade e percepção de valor.

## Texto de apoio

Para corretores, advogados, contadores, empresários e profissionais liberais, um cartão bem feito ajuda a reforçar confiança antes mesmo da próxima conversa.

## Bullets

- acabamentos premium;
- formatos personalizados;
- papel de alta qualidade;
- design alinhado à sua marca;
- produção sob encomenda.

## CTA secundário

Quero criar meu cartão premium

---

# Seção 3, Pastas e envelopes

## Eyebrow

Apresentação profissional

## Título

Pastas e envelopes que elevam a forma como sua empresa se apresenta.

## Descrição

Uma proposta, um contrato, um documento ou uma apresentação comercial não precisam chegar ao cliente de qualquer forma. Pastas e envelopes personalizados criam uma experiência mais organizada, elegante e confiável.

## Texto de apoio

Eles ajudam sua marca a parecer mais estruturada, reforçam o cuidado com o detalhe e tornam cada entrega física mais profissional.

## Bullets

- ideais para propostas e contratos;
- acabamento sofisticado;
- apresentação mais organizada;
- reforço de marca em reuniões;
- materiais feitos sob encomenda.

## CTA secundário

Quero uma apresentação mais profissional

---

# Seção 4, Panfletos e folders

## Eyebrow

Comunicação impressa

## Título

Panfletos e folders com presença, clareza e acabamento profissional.

## Descrição

Materiais informativos também podem ser sofisticados. Quando bem estruturados, panfletos e folders ajudam a apresentar serviços, imóveis, empresas, eventos e ofertas com mais clareza, sem perder a percepção de valor da marca.

## Texto de apoio

O objetivo não é apenas entregar informação. É entregar uma mensagem visualmente organizada, bem acabada e coerente com o público que você deseja atrair.

## Bullets

- comunicação clara;
- design alinhado à identidade da marca;
- ideal para apresentação de serviços;
- materiais comerciais e institucionais;
- produção personalizada.

## CTA secundário

Quero criar meu folder personalizado

---

# Seção 5, Confiança e diferenciais

## Eyebrow

Feito sob encomenda

## Título

Cada material é pensado para representar o nível da sua marca.

## Descrição

No Grupo Vittore, materiais gráficos não são tratados como produtos de prateleira. Cada pedido é feito sob encomenda, considerando o tipo de profissional, o público que ele atende, a imagem que deseja transmitir e o uso real do material.

## Bloco 1

### Personalizado para cada cliente

Nada de material genérico. Cada projeto é orientado para comunicar a presença, o posicionamento e o padrão visual da sua marca.

## Bloco 2

### Pedidos pelo WhatsApp

Todo atendimento acontece de forma prática pelo WhatsApp, com orientação para entender o que você precisa e qual material faz mais sentido para sua marca.

## Bloco 3

### Entrega para todo o Brasil

Produzimos materiais personalizados e enviamos para clientes em todo o Brasil, mantendo cuidado na produção, acabamento e entrega.

## Bloco 4

### Acabamento com intenção

Papel, textura, formato e acabamento não são detalhes aleatórios. Eles ajudam a construir a percepção que o cliente terá da sua marca.

## CTA

Falar com o Grupo Vittore

---

# Seção 6, Blocos de anotações

## Eyebrow

Relacionamento e presença

## Título

Blocos personalizados que mantêm sua marca presente na rotina do cliente.

## Descrição

Blocos de anotações personalizados são materiais simples na função, mas fortes na presença. Eles acompanham reuniões, atendimentos, mesas de trabalho, recepções e momentos em que sua marca continua visível depois do primeiro contato.

## Texto de apoio

São ideais para empresas, escritórios, consultores e profissionais que querem reforçar organização, cuidado e lembrança de marca no dia a dia.

## Bullets

- úteis em reuniões e atendimentos;
- reforçam presença de marca;
- personalizados com identidade visual;
- opção profissional para relacionamento;
- produção sob encomenda.

## CTA secundário

Quero blocos personalizados

---

# Seção 7, Prova social

## Eyebrow

Confiança comprovada

## Título

Mais de 200 avaliações no Google. Todas com 5 estrelas.

## Descrição

A confiança construída com nossos clientes aparece nos detalhes: no atendimento, na orientação, na produção e no cuidado com cada entrega.

## Depoimentos sugeridos

### Depoimento 1

Atendimento excelente, material de ótima qualidade e resultado muito profissional. Superou minhas expectativas.

### Depoimento 2

Ficou exatamente como eu queria. O acabamento transmite muito mais profissionalismo para a minha marca.

### Depoimento 3

Equipe muito atenciosa, me orientou em todo o processo e entregou um material impecável.

### Depoimento 4

A qualidade do material fez muita diferença na apresentação da minha empresa. Recomendo muito.

### Depoimento 5

O cartão ficou sofisticado, bem acabado e com uma presença muito superior ao comum.

### Depoimento 6

Pedido feito com segurança pelo WhatsApp, entrega no prazo e resultado excelente.

### Depoimento 7

A apresentação dos meus materiais mudou completamente a percepção dos meus clientes.

### Depoimento 8

Trabalho cuidadoso, bonito e muito profissional. Dá para perceber a diferença nos detalhes.

Observação:
Se existirem depoimentos reais do Google disponíveis, usar depoimentos reais. Não inventar depoimentos como se fossem reais. Os textos acima são placeholders de estrutura, caso o Hermes precise montar o layout sem os depoimentos oficiais.

---

# Seção 8, FAQ

## Eyebrow

Dúvidas frequentes

## Título

Antes de pedir seus materiais personalizados

## Perguntas e respostas

### Os pedidos são feitos somente por encomenda?

Sim. Cada material é produzido sob encomenda, de acordo com o tipo de peça, quantidade, acabamento, identidade visual e objetivo do cliente.

### Vocês entregam para todo o Brasil?

Sim. Atendemos clientes de diferentes regiões e enviamos os materiais personalizados para todo o Brasil.

### O pedido é feito pelo WhatsApp?

Sim. O atendimento inicial acontece pelo WhatsApp para entendermos o que você precisa, quais materiais deseja produzir e qual acabamento faz mais sentido.

### Vocês trabalham para todos os públicos?

Atendemos principalmente profissionais e empresas que buscam uma apresentação mais profissional, sofisticada e personalizada. O foco não é material genérico, mas impressos com mais cuidado, acabamento e presença.

### Quais materiais vocês produzem?

Produzimos cartões de visita, pastas, envelopes, panfletos, folders, blocos de anotações e outros materiais gráficos personalizados sob encomenda.

### Vocês criam a arte ou preciso enviar pronta?

O ideal é avaliar cada caso pelo WhatsApp. Podemos orientar sobre o melhor caminho conforme o material, a identidade visual existente e o nível de personalização desejado.

### Existe pedido mínimo?

Pode existir pedido mínimo dependendo do tipo de material, acabamento e fornecedor envolvido na produção. A confirmação acontece durante o atendimento pelo WhatsApp.

### Quanto tempo demora para produzir?

O prazo varia conforme o material, acabamento, quantidade e envio. Durante o atendimento, informamos o prazo estimado de produção e entrega.

### Posso pedir algo mais premium ou sofisticado?

Sim. Essa é justamente uma das propostas da frente de materiais gráficos do Grupo Vittore: criar impressos com mais presença, acabamento e percepção profissional.

---

# Seção 9, CTA final

## Eyebrow

Sua marca no mundo físico

## Título

Se a sua apresentação precisa transmitir mais valor, comece pelo material que o cliente vê, toca e guarda.

## Descrição

Materiais gráficos personalizados ajudam sua marca a sair do comum e a ocupar uma presença mais profissional na mente do cliente. Do cartão à pasta, do folder ao bloco de anotações, cada detalhe pode reforçar autoridade, confiança e sofisticação.

## CTA principal

Quero mais informações

## Microcopy

Fale pelo WhatsApp e solicite seu material sob encomenda.

---

# Seção 10, Rodapé

Usar exatamente o mesmo rodapé da LP de Assessoria Comercial.
