# Briefing estratégico, LP Materiais Gráficos Personalizados

## Contexto

O Grupo Vittore possui uma frente de Materiais Gráficos Personalizados com foco em impressos premium, feitos sob encomenda, para profissionais e empresas que desejam transmitir mais autoridade, sofisticação, confiança e presença física.

A landing page deve seguir a mesma identidade visual da landing page de Assessoria Comercial, mas com copy própria, voltada para materiais gráficos.

## Posicionamento da frente

A frente de Materiais Gráficos Personalizados não deve ser posicionada como gráfica popular, gráfica rápida ou fornecedora de preço baixo.

O posicionamento correto é:

> Materiais gráficos premium para profissionais e empresas que querem transformar sua marca em presença física, tangível e memorável.

## Frase guia

> Autoridade que se toca: impressos premium que materializam sua marca.

## Promessa central

Criar materiais gráficos personalizados que elevam a percepção de valor da marca e ajudam o profissional ou empresa a se apresentar com mais confiança, sofisticação e profissionalismo.

## Público-alvo prioritário

- corretores de imóveis;
- advogados;
- contadores;
- empresários;
- profissionais liberais;
- empresas locais;
- negócios que vendem serviço de confiança, relacionamento ou ticket maior.

## Desejo principal do público

O público quer ser percebido como mais profissional, confiável, estruturado e sofisticado antes mesmo da primeira conversa.

## Dor principal

Muitos profissionais têm boa entrega, mas a apresentação visual ainda não acompanha o nível do serviço. O material impresso atual não comunica o valor que eles querem transmitir.

## Diferenciais que precisam aparecer

- produção sob encomenda;
- materiais personalizados;
- orientação visual e técnica;
- foco em acabamento e presença;
- entrega para todo o Brasil;
- pedidos via WhatsApp;
- atendimento para profissionais e empresas que valorizam apresentação;
- impressos alinhados à identidade e ao posicionamento de cada cliente.

## O que não comunicar

Evitar linguagem de gráfica popular:

- cartão baratinho;
- promoção;
- arte grátis;
- fazemos qualquer coisa;
- preço baixo;
- impressão rápida sem critério;
- panfleto barato;
- gráfica online genérica.

## Tom da página

- premium;
- sofisticado;
- direto;
- seguro;
- persuasivo;
- elegante;
- sem exagero;
- sem linguagem robótica;
- sem excesso técnico.

## Objetivo de conversão

Levar o visitante para o WhatsApp com intenção de pedir orçamento, tirar dúvidas ou iniciar um pedido sob encomenda.

CTA principal sugerido:

> Quero mais informações

Variações possíveis:

> Solicitar orçamento pelo WhatsApp  
> Quero criar meus impressos premium  
> Falar sobre meu projeto
