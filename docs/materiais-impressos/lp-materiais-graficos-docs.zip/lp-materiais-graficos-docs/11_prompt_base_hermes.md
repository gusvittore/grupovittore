# Prompt base para Hermes, LP Materiais Gráficos Personalizados

Copiar este prompt quando for implementar a landing page.

```txt
Hermes, precisamos implementar a landing page de Materiais Gráficos Personalizados do Grupo Vittore.

ROTA ALVO:
Definir conforme padrão atual do projeto.

Preferência:
materiais-impressos

ou, se já existir rota criada:
materiais-graficos

Antes de implementar, confirme qual rota já existe no projeto e preserve o padrão existente. Não crie duas rotas para a mesma página.

==================================================
OBJETIVO
==================================================

Criar uma landing page de Materiais Gráficos Personalizados com a mesma identidade visual da landing page de Assessoria Comercial.

A página deve vender impressos premium, personalizados e sob encomenda, para profissionais e empresas que querem transmitir mais autoridade, sofisticação, confiança e presença física.

==================================================
DOCUMENTOS DE REFERÊNCIA
==================================================

Leia todos os documentos desta pasta antes de implementar:

docs/materiais-graficos/landing-page/

ou o caminho equivalente em que estes arquivos forem salvos.

Leia especialmente:

README.md
01_briefing_estrategico.md
03_posicionamento_e_mensagem.md
04_estrutura_da_landing_page.md
05_copy_final_landing_page.md
06_direcao_visual_e_identidade.md
07_regras_de_imagens_e_assets.md
08_regras_de_componentes_e_interacoes.md
09_faq_e_objecoes.md
10_whatsapp_conversao.md
12_checklist_validacao.md

Trate esses documentos como regras obrigatórias.

==================================================
REGRAS ABSOLUTAS
==================================================

NÃO alterar /assessoria-comercial.
NÃO alterar formulário da Assessoria Comercial.
NÃO alterar /api/leads.
NÃO alterar Supabase.
NÃO alterar ClickUp.
NÃO alterar envio de e-mail.
NÃO alterar Netlify Functions.
NÃO alterar /obrigado.
NÃO alterar /obrigado-qualificado.
NÃO alterar /politicas-de-privacidade.
NÃO alterar /termos-de-uso.
NÃO alterar Blog.
NÃO alterar artigos.
NÃO alterar página Sobre.
NÃO alterar Home institucional, exceto links que apontem para esta LP, se necessário.
NÃO alterar logotipo.
NÃO alterar paleta.
NÃO instalar biblioteca nova sem necessidade.
NÃO fazer commit automaticamente.

==================================================
IDENTIDADE VISUAL
==================================================

Usar a mesma identidade visual da LP de Assessoria Comercial:

- mesma tipografia;
- mesmo padrão de seções;
- mesmo botão verde;
- mesmo uso de azul marinho e off-white;
- mesmo padrão de hierarquia;
- mesmo rodapé exatamente igual.

O rodapé deve ser copiado/reutilizado da LP de Assessoria Comercial sem alteração visual.

==================================================
ESTRUTURA DA PÁGINA
==================================================

Seção 1:
Hero principal
Fundo azul marinho.
Sem logotipo dentro da Hero.
Textos em off-white com palavras em dourado.
Botão verde para WhatsApp.

Seção 2:
Cartões de visita
Fundo off-white.
Texto à esquerda.
Imagem à direita.

Seção 3:
Pastas e envelopes
Fundo off-white.
Imagem à esquerda.
Texto à direita.

Seção 4:
Panfletos e folders
Fundo off-white.
Texto à esquerda.
Imagem à direita.

Seção 5:
Confiança e diferenciais
Fundo azul marinho.
Benefícios à esquerda.
Título e descrição à direita.
Falar de entrega para todo o Brasil, pedidos por encomenda via WhatsApp e personalização.

Seção 6:
Blocos de anotações
Fundo off-white.
Imagem à esquerda.
Texto à direita.

Seção 7:
Prova social
Fundo off-white.
Depoimentos com 5 estrelas.
Duas linhas em movimento:
linha superior da direita para a esquerda;
linha inferior da esquerda para a direita.
Dar destaque para mais de 200 avaliações no Google, todas 5 estrelas.

Seção 8:
FAQ
Fundo off-white.
Centralizado.
Perguntas frequentes.

Seção 9:
CTA final
Fundo azul marinho.
Copy persuasiva final.
Botão verde para WhatsApp.

Seção 10:
Rodapé
Mesmo rodapé da LP de Assessoria Comercial.

==================================================
COPY
==================================================

Usar a copy definida em:

05_copy_final_landing_page.md

Pode ajustar pequenos trechos para caber no layout, mas não mudar o posicionamento.

Não transformar a página em texto de gráfica popular.
Não usar linguagem de promoção.
Não usar “baratinho”.
Não usar “arte grátis”.
Não usar linguagem genérica.

==================================================
WHATSAPP
==================================================

Todos os botões principais devem direcionar para WhatsApp.

CTA principal:
Quero mais informações

Mensagem padrão:
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre materiais gráficos personalizados.

Não inventar número.
Usar número oficial do projeto, se existir.
Se não existir, criar constante placeholder com comentário claro.

==================================================
PROVA SOCIAL
==================================================

Se existirem depoimentos reais do Google disponíveis no projeto, usar os reais.

Se não existirem, criar a estrutura visual com depoimentos placeholder claramente controlados, sem afirmar nomes reais falsos.

Manter destaque:
Mais de 200 avaliações no Google, todas 5 estrelas.

==================================================
RESPONSIVIDADE
==================================================

Testar em:
375px
390px
430px
desktop

Garantir:
- sem overflow horizontal;
- nenhuma palavra cortada;
- títulos com linhas controladas quando necessário;
- botões com boa área de toque;
- imagens bem ajustadas;
- depoimentos funcionando no mobile;
- FAQ legível.

==================================================
TESTES
==================================================

Rodar:

npm run build

Verificar:
- rota da LP carrega;
- /assessoria-comercial não foi alterada;
- /api/leads não foi alterada;
- WhatsApp abre corretamente;
- rodapé está igual ao da LP de Assessoria Comercial;
- sem erro TypeScript;
- sem erro de import;
- sem imagem quebrada.

==================================================
RELATÓRIO FINAL
==================================================

Ao finalizar, informe:

1. arquivos criados;
2. arquivos alterados;
3. rota final da página;
4. se reutilizou rodapé da Assessoria Comercial;
5. se preservou /assessoria-comercial;
6. se preservou /api/leads;
7. se os botões apontam para WhatsApp;
8. se implementou prova social;
9. se implementou FAQ;
10. se npm run build passou;
11. pendências;
12. não fazer commit automaticamente.
```
