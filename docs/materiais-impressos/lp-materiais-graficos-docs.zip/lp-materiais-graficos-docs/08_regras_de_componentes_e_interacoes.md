# Regras de componentes e interações

## Botões

Usar o mesmo padrão de botão verde da LP de Assessoria Comercial.

CTA principal:

> Quero mais informações

Destino:
WhatsApp oficial da frente de Materiais Gráficos Personalizados.

Se ainda não existir número definitivo no código, usar variável ou placeholder controlado, nunca inventar número.

## Links de WhatsApp

O link deve abrir em nova aba ou no app, conforme padrão do projeto.

Mensagem sugerida no WhatsApp:

```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre materiais gráficos personalizados.
```

Mensagem alternativa por seção:

Cartões:
```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre cartões de visita personalizados.
```

Pastas e envelopes:
```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre pastas e envelopes personalizados.
```

Panfletos e folders:
```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre panfletos e folders personalizados.
```

Blocos:
```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre blocos de anotações personalizados.
```

## Seção de prova social em movimento

Desejo visual:

- 2 linhas de depoimentos;
- 4 colunas visíveis no desktop;
- linha superior movendo da direita para a esquerda;
- linha inferior movendo da esquerda para a direita;
- cada card com 5 estrelas;
- destacar mais de 200 avaliações no Google, todas 5 estrelas.

Regras técnicas:

- animação suave;
- não exagerar na velocidade;
- pausar no hover, se possível;
- respeitar redução de movimento para acessibilidade;
- no mobile, usar carrossel horizontal ou rolagem suave;
- não quebrar layout.

Se o projeto já usa motion/animações, reutilizar padrão existente.

## FAQ

Pode ser acordeon ou cards empilhados.

Regras:

- pergunta clara;
- resposta curta e útil;
- boa área de clique no mobile;
- sem animação exagerada;
- texto legível;
- fundo off-white;
- tipografia consistente.

## Cards de benefícios

Na seção azul marinho, os benefícios podem ser exibidos em cards, lista ou blocos com ícones discretos.

Evitar ícones genéricos demais.

Priorizar texto, clareza e composição premium.

## Responsividade

Testar em:

- 375px;
- 390px;
- 430px;
- desktop comum;
- notebook.

Não permitir:

- palavra cortada;
- overflow horizontal;
- botão pequeno demais;
- carrossel quebrando;
- cards de depoimento sobrepostos;
- imagem estourando o container.
