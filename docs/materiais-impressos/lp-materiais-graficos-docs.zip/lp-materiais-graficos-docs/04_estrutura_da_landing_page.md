# Estrutura da Landing Page, Materiais Gráficos Personalizados

## Direção geral

A landing page deve seguir a identidade visual da LP de Assessoria Comercial.

Manter:

- mesma tipografia;
- mesmo estilo de diagramação;
- mesmo padrão de botões verdes;
- mesma paleta;
- mesmo rodapé da LP de Assessoria Comercial;
- ritmo visual premium;
- seções amplas, com respiro;
- alternância entre azul marinho e off-white.

## Seção 1, Hero principal

Fundo: azul marinho.

Conteúdo:
- não colocar logotipo dentro da Hero;
- textos em off-white;
- algumas palavras em dourado;
- botão verde igual ao da LP de Assessoria Comercial;
- CTA para WhatsApp.

Objetivo:
Comunicar rapidamente que a página não é sobre gráfica comum, mas sobre impressos premium que materializam autoridade.

## Seção 2, Cartões de visita

Fundo: off-white.

Layout:
- título e descrição à esquerda;
- fotos de cartões de visita à direita;
- textos em azul marinho.

Objetivo:
Apresentar cartões de visita como peça de autoridade, não apenas contato.

## Seção 3, Pastas e envelopes

Fundo: off-white.

Layout:
- fotos de pastas e envelopes à esquerda;
- título e descrição à direita;
- textos em azul marinho.

Objetivo:
Mostrar que materiais de apresentação elevam a percepção em reuniões, propostas e entregas.

## Seção 4, Panfletos e folders

Fundo: off-white.

Layout:
- título e descrição à esquerda;
- fotos de panfletos e folders à direita.

Objetivo:
Mostrar que panfletos e folders podem ser estratégicos, elegantes e informativos, quando bem pensados.

## Seção 5, Confiança e diferenciais

Fundo: azul marinho.

Layout:
- informações e benefícios à esquerda;
- título e descrições à direita;
- textos em off-white e detalhes em dourado.

Conteúdos obrigatórios:
- entrega para todo o Brasil;
- pedidos somente por encomenda via WhatsApp;
- tudo personalizado e exclusivo para cada cliente;
- materiais premium;
- orientação no processo;
- foco em profissionais e empresas que valorizam apresentação.

Objetivo:
Passar confiança e explicar como funciona.

## Seção 6, Blocos de anotações

Fundo: off-white.

Layout:
- fotos dos blocos à esquerda;
- título e descrição à direita.

Objetivo:
Mostrar blocos personalizados como material de relacionamento, presença e cuidado institucional.

## Seção 7, Prova social

Fundo: off-white.

Layout:
- título centralizado;
- subtítulo explicando mais de 200 avaliações 5 estrelas no Google;
- depoimentos em 2 linhas e 4 colunas visíveis;
- linha superior se move da direita para a esquerda;
- linha inferior se move da esquerda para a direita;
- cada depoimento com 5 estrelas.

Objetivo:
Reforçar confiança, satisfação e segurança na compra.

## Seção 8, FAQ

Fundo: off-white.

Layout:
- título centralizado;
- perguntas e respostas frequentes;
- textos em azul marinho;
- acordeon ou cards de pergunta.

Objetivo:
Reduzir objeções e orientar o visitante.

## Seção 9, CTA final

Fundo: azul marinho.

Conteúdo:
- copy persuasiva final;
- botão verde para WhatsApp;
- textos em off-white;
- palavras-chave em dourado.

Objetivo:
Encerrar com ação clara.

## Seção 10, Rodapé

Usar exatamente o mesmo rodapé da LP de Assessoria Comercial.

Não alterar:
- estrutura;
- logo;
- textos;
- links;
- cores;
- espaçamento;
- responsividade.
