# Direção visual e identidade

## Referência principal

A landing page de Materiais Gráficos Personalizados deve seguir a mesma identidade visual da landing page de Assessoria Comercial.

Manter o mesmo padrão de:

- tipografia;
- espaçamento;
- botões;
- ritmo visual;
- hierarquia;
- acabamento visual;
- premium institucional;
- rodapé.

## Paleta

Usar a paleta oficial do Grupo Vittore:

- azul marinho: `#000617` ou tom já usado na LP de Assessoria Comercial;
- off-white: `#FBF8F4`;
- dourado: `#B29157`;
- vermelho imperial: `#930101`, somente se já estiver previsto na identidade;
- verde CTA: `#008723`.

## Uso das cores

### Azul marinho

Usar em:

- Hero;
- seção de diferenciais;
- CTA final;
- fundos institucionais;
- áreas de maior autoridade.

### Off-white

Usar em:

- seções de produtos;
- FAQ;
- prova social;
- áreas de leitura.

### Dourado

Usar em:

- palavras estratégicas dentro dos títulos;
- detalhes pequenos;
- elementos de destaque;
- linhas sutis, se já fizer parte da LP de Assessoria Comercial.

Não exagerar no dourado.

### Verde

Usar apenas nos botões principais de conversão, seguindo o padrão da LP de Assessoria Comercial.

## Tipografia

A tipografia deve seguir exatamente o padrão da LP de Assessoria Comercial.

Não trocar fonte.
Não criar fonte nova.
Não usar peso aleatório.

## Hero

Regras:

- fundo azul marinho;
- sem logotipo dentro da Hero;
- título forte;
- palavras pontuais em dourado;
- botão verde;
- microcopy abaixo do botão;
- imagem ou composição visual relacionada a impressos premium, se for usada.

## Imagens

As imagens devem parecer reais, premium e profissionais.

Evitar:

- mockup barato;
- excesso de elementos;
- visual popular;
- imagens com aparência de IA evidente;
- papéis genéricos sem acabamento;
- composição poluída;
- pessoas em excesso;
- fotos que pareçam banco de imagem comum.

Preferir:

- close em cartões sofisticados;
- textura de papel;
- pastas premium;
- envelopes bem acabados;
- folders com boa diagramação;
- blocos personalizados;
- composição elegante;
- iluminação profissional;
- fundo neutro;
- alto contraste com sobriedade.

## Rodapé

Usar exatamente o mesmo rodapé da LP de Assessoria Comercial.

Não alterar:

- logo;
- links;
- textos;
- cores;
- espaçamentos;
- estrutura;
- responsividade.

## Mobile

A versão mobile deve seguir o padrão já aprendido no projeto:

- títulos com linhas controladas quando necessário;
- nada de palavra cortada;
- nada de overflow horizontal;
- títulos principais com hierarquia clara;
- subtítulos menores que títulos principais;
- cards legíveis;
- botões com boa área de toque;
- imagens sem cortes ruins.

## Desktop

No desktop:

- seções alternadas com texto e imagem;
- boa largura de leitura;
- imagens grandes e premium;
- muito respiro;
- layout sofisticado;
- alinhamentos alternados conforme o esboço.
