# Checklist de validação, LP Materiais Gráficos Personalizados

## Conteúdo

- [ ] Hero comunica impressos premium e autoridade tangível.
- [ ] A página não parece uma gráfica popular.
- [ ] A copy fala com corretores, advogados, contadores, empresários e profissionais liberais.
- [ ] O texto comunica profissionalismo, sofisticação, confiança e status com sobriedade.
- [ ] A página explica pedidos sob encomenda.
- [ ] A página explica entrega para todo o Brasil.
- [ ] A página informa atendimento pelo WhatsApp.
- [ ] A página apresenta cartões de visita.
- [ ] A página apresenta pastas e envelopes.
- [ ] A página apresenta panfletos e folders.
- [ ] A página apresenta blocos de anotações.
- [ ] A página contém FAQ.
- [ ] A página contém prova social.
- [ ] A página contém CTA final.

## Design

- [ ] Usa identidade visual da LP de Assessoria Comercial.
- [ ] Usa azul marinho nos blocos institucionais.
- [ ] Usa off-white nas seções de leitura.
- [ ] Usa dourado com moderação.
- [ ] Usa botão verde no mesmo padrão da Assessoria Comercial.
- [ ] Não coloca logotipo dentro da Hero.
- [ ] Mantém rodapé exatamente igual ao da LP de Assessoria Comercial.
- [ ] Mantém tipografia aprovada.
- [ ] Mantém diagramação premium.
- [ ] Não cria visual paralelo.

## Mobile

- [ ] Testado em 375px.
- [ ] Testado em 390px.
- [ ] Testado em 430px.
- [ ] Nenhuma palavra corta.
- [ ] Não existe overflow horizontal.
- [ ] Títulos ficam bem diagramados.
- [ ] Botões são fáceis de clicar.
- [ ] Imagens não quebram.
- [ ] Depoimentos funcionam sem poluir.
- [ ] FAQ é legível.

## Conversão

- [ ] Botão da Hero leva ao WhatsApp.
- [ ] Botões secundários levam ao WhatsApp.
- [ ] CTA final leva ao WhatsApp.
- [ ] Mensagem do WhatsApp está correta.
- [ ] Número de WhatsApp não foi inventado.
- [ ] Se não houver número, existe placeholder claro.

## Prova social

- [ ] Destaque para mais de 200 avaliações no Google.
- [ ] Texto informa 5 estrelas.
- [ ] Cards têm 5 estrelas.
- [ ] Linha superior move da direita para esquerda.
- [ ] Linha inferior move da esquerda para direita.
- [ ] Animação não atrapalha leitura.
- [ ] Respeita redução de movimento, se possível.

## Técnica

- [ ] `npm run build` passou.
- [ ] Sem erro TypeScript.
- [ ] Sem erro de importação.
- [ ] Sem imagem quebrada.
- [ ] Sem rota duplicada.
- [ ] `/assessoria-comercial` preservada.
- [ ] `/api/leads` preservada.
- [ ] Formulários da Assessoria preservados.
- [ ] Blog preservado.
- [ ] Artigos preservados.

## Relatório final esperado do Hermes

- [ ] arquivos criados;
- [ ] arquivos alterados;
- [ ] rota final;
- [ ] confirmação do rodapé reutilizado;
- [ ] confirmação dos botões de WhatsApp;
- [ ] confirmação da prova social;
- [ ] confirmação do FAQ;
- [ ] resultado do build;
- [ ] pendências.
