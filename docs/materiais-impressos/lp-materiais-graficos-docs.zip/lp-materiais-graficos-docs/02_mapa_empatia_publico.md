# Mapa de empatia, Materiais Gráficos Personalizados

## Quem é o público

Profissionais e empresas que vendem confiança, reputação e percepção de valor.

Inclui:

- corretores de imóveis autônomos;
- advogados;
- contadores;
- empresários;
- profissionais liberais;
- consultores;
- empresas locais;
- negócios que atendem clientes de maior ticket.

Essas pessoas não querem apenas imprimir materiais. Elas querem se apresentar melhor.

## O que pensam e sentem

Pensamentos frequentes:

- “Meu serviço é bom, mas minha apresentação ainda não comunica isso.”
- “Quero parecer mais profissional.”
- “Não posso chegar numa reunião com material simples demais.”
- “Se eu quero atender clientes melhores, minha marca precisa acompanhar.”
- “Tem gente inferior tecnicamente, mas se apresentando melhor.”
- “Quero algo elegante, mas sem exagero.”
- “Não quero parecer amador.”
- “Quero que o cliente perceba valor antes de perguntar preço.”

Sentimentos principais:

- desejo de ser respeitado;
- medo de parecer pequeno;
- incômodo com materiais comuns;
- vontade de se diferenciar;
- busca por status profissional;
- necessidade de confiança;
- orgulho quando a marca fica bem apresentada.

## O que veem

- concorrentes com materiais mais sofisticados;
- cartões de visita mais elegantes;
- pastas de apresentação mais profissionais;
- marcas que parecem mais estruturadas;
- clientes valorizando cuidado visual;
- empresas que transmitem confiança pelo detalhe;
- materiais simples demais passando sensação de improviso.

## O que ouvem

Frases comuns:

- “Me manda seu cartão.”
- “Você tem uma apresentação?”
- “Me envia sua proposta.”
- “Deixa seu contato aqui.”
- “Esse material ficou muito profissional.”
- “Parece empresa grande.”
- “Passa mais confiança.”

Também ouvem muitos fornecedores falando apenas de preço, prazo e quantidade. Poucos falam de percepção, posicionamento e presença.

## O que falam e fazem

Frases que costumam dizer:

- “Quero algo mais profissional.”
- “Não quero nada muito simples.”
- “Quero algo elegante.”
- “Preciso de um cartão bonito.”
- “Quero uma pasta mais premium.”
- “Quero algo que passe confiança.”
- “Não quero coisa muito chamativa.”
- “Meu público é mais exigente.”

Comportamentos:

- pesquisam referências no Instagram;
- salvam modelos de cartão, pasta e papelaria;
- pedem opinião antes de aprovar;
- comparam preço, mas não querem necessariamente o mais barato;
- valorizam prova visual e simulação;
- procuram fornecedores que orientem.

## Dores

### Parecer menor do que realmente é

O profissional tem boa entrega, mas sua apresentação visual não acompanha a qualidade do serviço.

### Perder autoridade na primeira impressão

Um cartão comum, uma pasta simples ou um impresso mal acabado pode reduzir a percepção de valor.

### Depender apenas do digital

Instagram, WhatsApp e site ajudam, mas o cliente também precisa de algo físico que fique com ele.

### Não saber escolher acabamento

O cliente quer algo premium, mas não sabe escolher papel, gramatura, textura, laminação, verniz, hot stamping ou formato.

### Medo de investir e se frustrar

Existe receio de aprovar algo e o resultado parecer barato, exagerado ou diferente do esperado.

### Fornecedores muito operacionais

Muitos fornecedores perguntam apenas quantidade, tamanho e prazo. Esse público quer orientação.

## Ganhos desejados

- transmitir mais profissionalismo;
- causar boa primeira impressão;
- fortalecer a presença da marca;
- parecer mais estruturado;
- elevar percepção de valor;
- diferenciar-se de concorrentes comuns;
- ter materiais alinhados ao público que deseja atrair;
- sentir orgulho ao entregar o próprio material;
- justificar melhor o valor cobrado;
- ter uma presença física memorável.

## Objeções comuns

- “Está caro.”
- “Vou pensar.”
- “Já tenho cartão.”
- “Meu foco hoje é digital.”
- “Tenho uma gráfica que faz mais barato.”
- “Não sei se preciso disso agora.”
- “Vou fazer só o básico.”

O que está por trás:

- medo de não valer o investimento;
- falta de clareza sobre o impacto na percepção;
- insegurança sobre acabamento;
- dúvida sobre como usar os materiais;
- visão de material gráfico como custo, não como presença.

## Gatilhos de decisão

- acabamento premium;
- orientação segura;
- prova visual;
- percepção de exclusividade;
- atendimento consultivo;
- clareza no processo;
- facilidade pelo WhatsApp;
- entrega para todo o Brasil;
- materiais personalizados;
- confiança de mais de 200 avaliações 5 estrelas no Google.

## Síntese

Esse público não procura apenas uma gráfica. Ele procura um material que confirme, no mundo físico, a autoridade que deseja ocupar no mercado.

Ele quer que a marca seja percebida como profissional antes mesmo que precise se explicar.
