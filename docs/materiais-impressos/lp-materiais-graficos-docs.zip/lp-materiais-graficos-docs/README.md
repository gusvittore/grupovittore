# Landing Page Materiais Gráficos Personalizados

Este pacote reúne os documentos de orientação para criação e implementação da landing page de Materiais Gráficos Personalizados do Grupo Vittore.

A página deve seguir a mesma identidade visual da landing page de Assessoria Comercial, preservando:
- tipografia;
- diagramação premium;
- uso de azul marinho, off-white, dourado e botão verde;
- rodapé exatamente igual ao da LP de Assessoria Comercial;
- tom institucional, sofisticado e persuasivo;
- experiência mobile e desktop consistente.

## Objetivo da landing page

Vender materiais gráficos personalizados como extensão física da autoridade da marca, não como simples produto de gráfica.

A página deve comunicar:

> Autoridade que se toca: impressos premium que materializam sua marca.

## Público principal

- corretores de imóveis autônomos;
- advogados;
- contadores;
- empresários;
- profissionais liberais;
- empresas que querem elevar a percepção de profissionalismo, sofisticação e confiança.

## Estrutura dos documentos

1. `01_briefing_estrategico.md`
2. `02_mapa_empatia_publico.md`
3. `03_posicionamento_e_mensagem.md`
4. `04_estrutura_da_landing_page.md`
5. `05_copy_final_landing_page.md`
6. `06_direcao_visual_e_identidade.md`
7. `07_regras_de_imagens_e_assets.md`
8. `08_regras_de_componentes_e_interacoes.md`
9. `09_faq_e_objecoes.md`
10. `10_whatsapp_conversao.md`
11. `11_prompt_base_hermes.md`
12. `12_checklist_validacao.md`

## Caminho sugerido no projeto

Salvar estes arquivos em:

```txt
docs/materiais-graficos/landing-page/
```

ou, se o projeto já tiver uma pasta oficial da frente de materiais gráficos:

```txt
docs/materiais-impressos/landing-page/
```

Não salvar estes documentos dentro de `public`, pois são regras internas do projeto, não assets públicos.
