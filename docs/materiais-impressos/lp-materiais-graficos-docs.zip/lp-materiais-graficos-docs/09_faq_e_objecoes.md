# FAQ e objeções

## Objetivo

A FAQ deve reduzir dúvidas e objeções antes do clique no WhatsApp.

Deve responder de forma clara, sem parecer texto jurídico ou atendimento robotizado.

## Perguntas recomendadas

### Os pedidos são feitos somente por encomenda?

Sim. Cada material é produzido sob encomenda, considerando o tipo de peça, quantidade, acabamento, identidade visual e objetivo do cliente.

### Vocês entregam para todo o Brasil?

Sim. O Grupo Vittore atende clientes de diferentes regiões e envia materiais personalizados para todo o Brasil.

### O pedido é feito pelo WhatsApp?

Sim. O atendimento inicial acontece pelo WhatsApp para entendermos o que você precisa, orientar as possibilidades e seguir com o orçamento.

### Vocês trabalham para todos os públicos?

Atendemos principalmente profissionais e empresas que querem uma apresentação mais profissional, sofisticada e personalizada. O foco não é material genérico, mas impressos com mais presença e acabamento.

### Quais materiais vocês produzem?

Cartões de visita, pastas, envelopes, panfletos, folders, blocos de anotações e outros materiais gráficos personalizados sob encomenda.

### Vocês fazem materiais premium?

Sim. Podemos orientar escolhas de papel, acabamento, formato e apresentação para criar materiais com percepção mais sofisticada.

### Preciso já ter a arte pronta?

Não necessariamente. O ideal é conversar pelo WhatsApp para entendermos se você já possui identidade visual, arquivo pronto ou se precisa de orientação para preparar o material.

### Existe quantidade mínima?

Pode existir quantidade mínima dependendo do tipo de material, acabamento e produção. Isso é informado durante o atendimento.

### Qual é o prazo de produção?

O prazo varia conforme material, acabamento, quantidade e entrega. Durante o orçamento, informamos a previsão de produção e envio.

### Consigo pedir mais de um tipo de material no mesmo atendimento?

Sim. Você pode solicitar cartão, pasta, envelope, folder, panfleto, bloco ou outros materiais no mesmo atendimento.

### Vocês atendem corretores, advogados e contadores?

Sim. Esses são alguns dos públicos que mais procuram materiais gráficos para transmitir confiança, autoridade e profissionalismo.

## Objeções e respostas estratégicas

### “Meu foco é digital.”

Resposta estratégica:
Presença digital é importante, mas ela não substitui todos os pontos de contato. Em reuniões, entregas, propostas e apresentações, o material físico ainda ajuda a construir confiança.

### “Já tenho cartão.”

Resposta estratégica:
A questão não é apenas ter cartão. É se o cartão atual comunica o nível de profissionalismo que você deseja transmitir.

### “Tenho uma gráfica mais barata.”

Resposta estratégica:
Preço importa, mas materiais premium exigem cuidado com acabamento, percepção e apresentação. A proposta do Grupo Vittore não é competir por impressão comum, mas criar presença física para a marca.

### “Não sei qual material pedir.”

Resposta estratégica:
O atendimento pelo WhatsApp serve justamente para entender o seu contexto e orientar o material mais adequado.

### “Tenho medo de ficar exagerado.”

Resposta estratégica:
A proposta é sofisticação com sobriedade, não excesso. O material precisa reforçar sua autoridade sem parecer forçado.
