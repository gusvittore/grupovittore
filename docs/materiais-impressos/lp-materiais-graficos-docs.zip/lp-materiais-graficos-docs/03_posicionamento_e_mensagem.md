# Posicionamento e mensagem da LP

## Posicionamento central

O Grupo Vittore cria materiais gráficos premium para profissionais e empresas que querem transformar sua marca em presença física, tangível e memorável.

## Ideia principal

O impresso não é apenas papel. Ele é uma extensão física da marca.

Quando bem feito, comunica:

- profissionalismo;
- cuidado;
- autoridade;
- confiança;
- sofisticação;
- percepção de valor.

## Mensagem-mãe

> Sua marca também é percebida no que o cliente toca.

## Frase institucional da frente

> Autoridade que se toca: impressos premium que materializam sua marca.

## Promessa

Materiais gráficos personalizados, produzidos sob encomenda, para profissionais e empresas que querem se apresentar com mais autoridade, sofisticação e confiança.

## Subpromessas

- Cartões de visita que não parecem comuns.
- Pastas e envelopes que elevam a apresentação da marca.
- Panfletos e folders com comunicação profissional.
- Blocos de anotações personalizados que fortalecem presença e relacionamento.
- Impressos criados sob encomenda, de acordo com cada cliente.
- Entrega para todo o Brasil.
- Atendimento e pedidos pelo WhatsApp.

## Tom de voz

A copy deve soar:

- elegante;
- direta;
- segura;
- premium;
- humana;
- estratégica;
- sofisticada sem ser exagerada.

## O que evitar

Evitar termos populares e promocionais:

- barato;
- promoção;
- gráfica rápida;
- qualquer quantidade;
- arte grátis;
- panfleto barato;
- entrega relâmpago;
- melhor preço.

Evitar frases genéricas:

- “soluções completas para sua empresa”;
- “qualidade e compromisso”;
- “atendimento diferenciado”;
- “transformamos seu sonho em realidade”;
- “somos apaixonados por imprimir”.

## Vocabulário recomendado

- presença;
- autoridade;
- impressão;
- detalhe;
- acabamento;
- sofisticação;
- marca;
- percepção;
- confiança;
- materialidade;
- apresentação;
- profissionalismo;
- valor;
- posicionamento;
- sob encomenda;
- personalizado;
- premium;
- tangível.

## Frases úteis

- Presença profissional não termina no digital.
- Antes da proposta ser lida, a apresentação já comunica algo.
- O detalhe também vende percepção.
- Um material bem feito não fala mais alto. Fala melhor.
- Sua marca precisa ser lembrada depois da reunião.
- O papel, o acabamento e a textura também constroem confiança.
- Quem vende confiança precisa cuidar da própria apresentação.
