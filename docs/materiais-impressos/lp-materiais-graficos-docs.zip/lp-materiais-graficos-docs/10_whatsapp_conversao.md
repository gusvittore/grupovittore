# WhatsApp e conversão

## Objetivo do WhatsApp

O WhatsApp é o principal canal de conversão da landing page.

A página deve levar o visitante a iniciar uma conversa com intenção clara.

## CTA principal

> Quero mais informações

## Mensagem padrão

```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre materiais gráficos personalizados.
```

## Mensagens por seção

### Hero

```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre materiais gráficos personalizados.
```

### Cartões de visita

```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre cartões de visita personalizados.
```

### Pastas e envelopes

```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre pastas e envelopes personalizados.
```

### Panfletos e folders

```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre panfletos e folders personalizados.
```

### Blocos de anotações

```txt
Olá, vim pelo site do Grupo Vittore e quero mais informações sobre blocos de anotações personalizados.
```

### CTA final

```txt
Olá, vim pelo site do Grupo Vittore e quero criar materiais gráficos personalizados para minha marca.
```

## Regras

- Não inventar número de WhatsApp.
- Usar o número oficial já configurado no projeto, se existir.
- Se não existir número configurado, criar constante ou placeholder claro para o Gustavo preencher.
- Não espalhar número manualmente em vários componentes.
- Centralizar a URL de WhatsApp em um helper, constante ou config, se fizer sentido.
- Codificar a mensagem com encodeURIComponent.
- Abrir em nova aba quando adequado.
- Manter acessibilidade nos botões.

## Eventos futuros

Se futuramente forem instalados Analytics, Pixel ou GTM, os cliques nos botões de WhatsApp podem receber eventos como:

- `whatsapp_click_hero`
- `whatsapp_click_cartoes`
- `whatsapp_click_pastas`
- `whatsapp_click_folders`
- `whatsapp_click_blocos`
- `whatsapp_click_cta_final`

Não implementar rastreamento agora se o projeto ainda não usa.
